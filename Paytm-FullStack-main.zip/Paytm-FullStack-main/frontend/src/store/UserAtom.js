import {atom} from "recoil"


export const userAuth=atom({
    key:"userAuth",
    default:false,
})